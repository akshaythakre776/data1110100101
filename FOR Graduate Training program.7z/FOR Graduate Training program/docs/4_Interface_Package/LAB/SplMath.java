package cg.javaflp.practice;

public class SplMath implements ISplMath {

	@Override
	public double add(double firstNumber, double secondNumber) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double substract(double firstNumber, double secondNumber) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double multiple(double firstNumber, double secondNumber) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double divide(double firstNumber, double secondNumber) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double modulus(double firstNumber, double secondNumber) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double sqrt(double number) {
		// TODO Auto-generated method stub
		return 0;
	}

}
