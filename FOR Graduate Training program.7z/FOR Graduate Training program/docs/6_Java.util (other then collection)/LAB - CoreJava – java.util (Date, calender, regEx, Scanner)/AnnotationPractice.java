package cg.javaflp.practice;

@MyfirstAnnotation(dob = "14/10/1980", emailId = "vivsinha@capgemini.com", name = "Vivek Sinha")
public class AnnotationPractice {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
