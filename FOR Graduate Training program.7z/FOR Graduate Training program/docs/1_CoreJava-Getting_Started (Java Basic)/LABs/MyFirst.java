package tdi.javaFLP.languageBasic;

/**
 * 
 * @author vivsinha
 * This is my first java class, 
 * And in this class I am printing (displaying) a message on console
 */

public class MyFirst {

	/**
	 * Main method - this is staring point of my program.
	 * When I run the program, 
	 * JVM will look for this method and program will start execution  
	 */
	
public static void main(String[] args) {
		
		// using System.out.println to print a message on console
		System.out.println("Yeeeeeee, My first Java program. :-) ");
	}
}
