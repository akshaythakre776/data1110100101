package cg.javaflp.practice;

public class ThreadMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ThreadPractice practice1 = new ThreadPractice("First ");
		ThreadPractice practice2 = new ThreadPractice("Second ");
		/*
		practice1.display();
		practice2.display();
		
		new Thread(practice1).start();
		new Thread(practice2).start();
		*/
		
		/*
		ThreadExtendPractice practice1 = new ThreadExtendPractice("First");
		ThreadExtendPractice practice2 = new ThreadExtendPractice("Second");
		 */
	}

}
