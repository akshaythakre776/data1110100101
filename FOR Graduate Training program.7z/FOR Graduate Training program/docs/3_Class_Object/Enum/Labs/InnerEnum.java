package cg.javaflp.practice;

public class InnerEnum {
	
	public enum Direction{
		NORTH, SOUTH, EAST, WEST
	}
	
}
